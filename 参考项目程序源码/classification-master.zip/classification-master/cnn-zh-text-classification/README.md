# cnn-zh-text-classification
基于 CNN 的中文文本分类
