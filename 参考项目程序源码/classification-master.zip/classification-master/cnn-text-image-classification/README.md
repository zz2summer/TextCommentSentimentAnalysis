# cnn-text-image-classification
基于 CNN 的图像文本关联分类
